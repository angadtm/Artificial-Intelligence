Name  : Angad Tarikere Manjunatha
UTA ID: 1001718335

Languages Used
*****************************************************************
Programming Language used is Python(Python 3.9.5) and its not Omega compatible.

Tools Used
****************************************************************
VS Code

Algorithms Used
****************************************************************
Uninformed Cost Search Algorithm - Used for Uninformed Graph Search
A* Search Algorithm - Used for Informed Graph Search

Files
****************************************************************
find_route.py - This python file contains the code to finding path using Informed and Uninformed Cost Search.
inputFile.txt - This input file describes road connections between cities in some part of the world.
h_value.txt - This file contains heuristic values for every state (assuming kassel is the goal). 
Note:The python file and input files have to be in the same folder.

How to Execute
****************************************************************
Use this command to run the code in the Command Prompt: 
For informed search  --> python find_route.py inputfile source destination heuristicfile
For uninformed search --> python find_route.py inputfile source destination
Ex: For Informed Search - python find_route.py inputFile.txt Bremen Dortmund h_value.txt
    For Uninformed Search - python find_route.py inputFile.txt Bremen Dortmund







