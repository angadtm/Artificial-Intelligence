import sys

#Reading the data from InputFile and storing it.
def initialize(inputFile):
    for each_line in inputFile:
        if "END OF INPUT" in each_line:
            break
        else:
            tmpVar = each_line.strip().split(" ")
            City_1 = tmpVar[0]
            City_2 = tmpVar[1]
            if City_1 in city_List:
                pass
            else:
                city_List.append(City_1)
            if City_2 in city_List:
                pass
            else:
                city_List.append(City_2)

    city_List.sort()
    for i in range(len(city_List)):
        map_cities.append([])
        for j in range(len(city_List)):
            map_cities[i].append(-1)
        map_cities[i][i] = 0

    for each_line in inputFile:
        if "END OF INPUT" in each_line:
            break
        else:
            t = each_line.strip().split(" ")
            City_1 = t[0]
            City_2 = t[1]
            distance = t[2]
            map_cities[city_List.index(City_1)][city_List.index(City_2)] = float(distance)
            map_cities[city_List.index(City_2)][city_List.index(City_1)] = float(distance)
    return


def getRoute(destination_Path, nodes):
    pathToNode = []

    def backTrackPath(destination, nodesTouch):
        if destination == 'None':
            return
        else:
            for nextNode in nodesTouch:
                if nextNode["node"] == destination:
                    pathToNode.append(destination)
                    backTrackPath(nextNode["parentNode"], nodesTouch)

    if destination_Path:
        print("distance: " + str(destination_Path["Total_Cost"])+" km")
        print("Route: ")
        backTrackPath(destination_Path["Current"], nodes)
        pathToNode.reverse()
        for i in range(0, len(pathToNode) - 1):
            print(city_List[pathToNode[i]] + " TO " + city_List[pathToNode[i + 1]] + ", " + str(
                map_cities[pathToNode[i]][pathToNode[i + 1]]) + " km")
    else:
        print("distance: Infinity")
        print("Route:")
        print("None")
    return

def getPrioritizedFringe(fringe, flag):
    if (len(fringe) > 1):
        for node_i in range(0, len(fringe) - 1):
            least = node_i
            for node_j in range(node_i + 1, len(fringe)):
                p = fringe[least]["Total_Cost"]
                q = fringe[node_j]["Total_Cost"]
                if flag:
                    p += fringe[least]["hcost"]
                    q += fringe[node_j]["hcost"]
                if (p > q):
                    least = node_j
            tmp = fringe[least]
            fringe[least] = fringe[node_i]
            fringe[node_i] = tmp
        return fringe
    else:
        return fringe


#checks if the Node is already Visited
def checkVisitedNodes(currentNodeIndex, listNodes):
    for node in listNodes:
        if currentNodeIndex == node["node"]:
            return True
    return False

def readHeuristicValues(inputFile):
    for each_line in inputFile:
        if "END OF INPUT" in each_line:
            break
        else:
            line_data = each_line.split(" ")
            heuristics[city_List.index(line_data[0])] = int(line_data[1])
    return

# Function for finding the path using Informed Cost Search algorithm
def informedSearch():
    goal = city_List.index(goalState)
    nodeGenerated = 1
    nodeExpanded= 0
    popped_node = 0
    fringeSizeMax = 0
    i_fringe = []
    visitedNodesList = []
    endFlag = False
    i_fringe.append({
        "Current": city_List.index(sourceState),
        "Total_Cost": 0,
        "hcost": heuristics[city_List.index(sourceState)],
        "parentNode": None
    })
    while (len(i_fringe) > 0):
        nodeExpanded = nodeExpanded + 1
        if i_fringe[0]["Current"] == goal:
            visitedNodesList.append({
                "node": i_fringe[0]["Current"],
                "parentNode": i_fringe[0]["parentNode"]
            })
            endFlag = i_fringe[0]
            break
        elif checkVisitedNodes(i_fringe[0]["Current"], visitedNodesList):
            del i_fringe[0]
            continue
        else:
            visitedNodesList.append({
                "node": i_fringe[0]["Current"],
                "parentNode": i_fringe[0]["parentNode"]
            })
            for i in range(len(map_cities[i_fringe[0]["Current"]])):
                if map_cities[i_fringe[0]["Current"]][i] > 0:
                    i_fringe.append({
                        "Current": i,
                        "Total_Cost": i_fringe[0]["Total_Cost"] + map_cities[i_fringe[0]["Current"]][i],
                        "hcost": heuristics[i],
                        "parentNode": i_fringe[0]["Current"]
                    })
                    nodeGenerated = nodeGenerated + 1
            del i_fringe[0]
            popped_node = popped_node + 1
            i_fringe = getPrioritizedFringe(i_fringe, True)

        if (len(i_fringe) > fringeSizeMax):
            fringeSizeMax = len(i_fringe)
    print("Nodes Popped: " + str(nodeExpanded))
    print("Nodes Expanded: " + str(popped_node))
    print("Nodes Generated: " + str(nodeGenerated))
    getRoute(endFlag, visitedNodesList)
    return


# Function for finding the path using Uniformed Cost Search algorithm
def uninformedSearch():
    goal = city_List.index(goalState)
    nodeGenerated = 1
    nodeExpanded = 0
    popped_node = 0
    fringeSizeMax = 0
    u_fringe = []
    visitedNodesList = []
    endFlag = False
    u_fringe.append({
        "Current": city_List.index(sourceState),
        "Total_Cost": 0,
        "parentNode": None
    })
    while (len(u_fringe) > 0):
        nodeExpanded = nodeExpanded + 1
        if u_fringe[0]["Current"] == goal:
            visitedNodesList.append({
                "node": u_fringe[0]["Current"],
                "parentNode": u_fringe[0]["parentNode"]
            })
            endFlag = u_fringe[0]
            break
        elif checkVisitedNodes(u_fringe[0]["Current"], visitedNodesList):
            del u_fringe[0]
            continue
        else:
            visitedNodesList.append({
                "node": u_fringe[0]["Current"],
                "parentNode": u_fringe[0]["parentNode"]
            })
            for i in range(len(map_cities[u_fringe[0]["Current"]])):
                if map_cities[u_fringe[0]["Current"]][i] > 0:
                    u_fringe.append({
                        "Current": i,
                        "Total_Cost": u_fringe[0]["Total_Cost"] + map_cities[u_fringe[0]["Current"]][i],
                        "parentNode": u_fringe[0]["Current"]
                    })
                    nodeGenerated = nodeGenerated + 1
            popped_node = popped_node + 1
            del u_fringe[0]
            u_fringe = getPrioritizedFringe(u_fringe, False)

        if len(u_fringe) > fringeSizeMax:
            fringeSizeMax = len(u_fringe)
    print("Nodes Popped: " + str(nodeExpanded))
    print("Nodes Expanded: " + str(popped_node))
    print("Nodes Generated: " + str(nodeGenerated))
    getRoute(endFlag, visitedNodesList)
    return
# Getting the Commandline arguments from the Terminal
if len(sys.argv) >= 4:
    city_List = []
    map_cities = []

    initialize(open(sys.argv[1], "r").read().split("\n"))
    sourceState = sys.argv[2]
    goalState = sys.argv[3]

    if len(sys.argv) != 5:
        uninformedSearch()
    elif len(sys.argv) == 5:
        heuristics = [0] * len(city_List)
        heuristicValuesInput = sys.argv[4]
        readHeuristicValues(open(sys.argv[4], "r").read().split("\n"))
        informedSearch()
    else:
        print(" Check the number of arguments entered")
